// Complete Limited Edition Watch Collection with Stock Management
// As an authorized dealer, replace these public image URLs with your official dealer portal assets when ready.

export interface Watch {
  id: string;
  name: string;
  brand: string;
  price: number;
  description: string;
  image: string;
  reference: string;
  condition: string;
  year: number;
  originalBox: boolean;
  originalPapers: boolean;
  movement: string;
  caseSize: string;
  material: string;
  stock: number; // Stock quantity - 0 means out of stock
  limitedEdition: boolean;
  limitedNumber?: string; // e.g., "45/100"
  featured: boolean;
}

// IMAGE NOTES FOR AUTHORIZED DEALER:
// Patek Philippe, Richard Mille, Audemars Piguet, and Omega now use real public product/editorial image URLs.
// For production, the most reliable setup is to download your approved dealer portal assets,
// store them in /public/images/watches/, then reference them as '/images/watches/your-image-name.jpg'.

export const luxuryWatches: Watch[] = [
  // ============================================
  // ROLEX LIMITED EDITIONS
  // ============================================
  {
    id: 'rolex-1',
    name: 'Daytona Rainbow',
    brand: 'Rolex',
    price: 485000,
    description: 'The legendary Daytona Rainbow features a stunning bezel set with 36 baguette-cut sapphires in rainbow gradation. A true masterpiece that represents the pinnacle of Rolex gem-setting artistry.',
    image: 'https://www.jfjco.com/wp-content/uploads/2019/02/5e70b600b918a47bbb02c88a2d0c194e.jpg',
    reference: '116595RBOW',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 4130',
    caseSize: '40mm',
    material: '18ct Everose Gold',
    stock: 1,
    limitedEdition: true,
    limitedNumber: 'Rare Production',
    featured: true
  },
  {
    id: 'rolex-2',
    name: 'GMT-Master II Pepsi',
    brand: 'Rolex',
    price: 22500,
    description: 'The iconic Pepsi bezel GMT-Master II with red and blue Cerachrom ceramic bezel. A pilot\'s watch that has become one of the most sought-after timepieces in the world.',
    image: 'https://timeandtidewatches.com/wp-content/uploads/2020/12/Rolex-GMT-Pepsi-126710-BLRO-5.jpg',
    reference: '126710BLRO',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3285',
    caseSize: '40mm',
    material: 'Oystersteel',
    stock: 3,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'rolex-3',
    name: 'Submariner Date "Hulk"',
    brand: 'Rolex',
    price: 28500,
    description: 'The legendary "Hulk" Submariner with its distinctive green sunburst dial and green Cerachrom bezel. Discontinued model, highly collectible.',
    image: 'https://timeandtidewatches.com/wp-content/uploads/2020/12/Rolex-Submariner-Hulk-116610LV-1.jpg',
    reference: '116610LV',
    condition: 'Pre-owned',
    year: 2020,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3135',
    caseSize: '40mm',
    material: 'Oystersteel',
    stock: 2,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rolex-4',
    name: 'Daytona Platinum Ice Blue',
    brand: 'Rolex',
    price: 125000,
    description: 'The platinum Daytona with ice blue dial and chocolate brown Cerachrom bezel. The most prestigious Daytona in the collection, worn by legends.',
    image: 'https://res.cloudinary.com/storage-41watch/image/upload/v1737643576/DSC_0679_2_18364cffaf.jpg',
    reference: '116506',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 4130',
    caseSize: '40mm',
    material: '950 Platinum',
    stock: 1,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'rolex-5',
    name: 'Day-Date 40 Green Dial',
    brand: 'Rolex',
    price: 42000,
    description: 'The President\'s watch in 18ct yellow gold with an exclusive olive green dial. A symbol of success and achievement since 1956.',
    image: 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
    reference: '228238',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3255',
    caseSize: '40mm',
    material: '18ct Yellow Gold',
    stock: 2,
    limitedEdition: false,
    featured: false
  },
  {
    id: 'rolex-6',
    name: 'GMT-Master II Sprite',
    brand: 'Rolex',
    price: 19500,
    description: 'The left-handed GMT-Master II with distinctive black and green bezel. A revolutionary design that celebrates innovation.',
    image: 'https://static.chrono24.com/images/default/logos/chrono24-logo.svg',
    reference: '126720VTNR',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3285',
    caseSize: '40mm',
    material: 'Oystersteel',
    stock: 0, // OUT OF STOCK - Set by dealer
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rolex-7',
    name: 'Submariner Date "Starbucks"',
    brand: 'Rolex',
    price: 18500,
    description: 'The modern classic with black dial and green bezel. The perfect evolution of the legendary diver\'s watch.',
    image: 'https://www.thedocwatches.com/wp-content/uploads/2020/10/IMG_8327-scaled.jpeg',
    reference: '126610LV',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3235',
    caseSize: '41mm',
    material: 'Oystersteel',
    stock: 4,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rolex-8',
    name: 'Sky-Dweller Blue Dial',
    brand: 'Rolex',
    price: 55000,
    description: 'The most complicated Rolex with annual calendar and dual time zone. A triumph of engineering and elegance.',
    image: 'https://images.unsplash.com/photo-1612817288484-6f916006741a?w=800&q=80',
    reference: '326934',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 9001',
    caseSize: '42mm',
    material: 'Oystersteel & White Gold',
    stock: 2,
    limitedEdition: false,
    featured: false
  },
  {
    id: 'rolex-9',
    name: 'Cosmograph Daytona "Panda"',
    brand: 'Rolex',
    price: 38500,
    description: 'The legendary Panda dial Daytona with white dial and black sub-dials. The most iconic chronograph in the world.',
    image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800&q=80',
    reference: '116500LN',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 4130',
    caseSize: '40mm',
    material: 'Oystersteel',
    stock: 1,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'rolex-10',
    name: 'Yacht-Master 42 Titanium',
    brand: 'Rolex',
    price: 14500,
    description: 'The Yacht-Master 42 in titanium - the lightest and most technical professional watch in the Rolex collection.',
    image: 'https://www.hlgross.com/cdn/shop/files/m226627-0001_upright_watch_0879f341-5084-45b3-a4fa-489b41f30195_1080x.png',
    reference: '226627',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 3235',
    caseSize: '42mm',
    material: 'RLX Titanium',
    stock: 3,
    limitedEdition: true,
    featured: false
  },

  // ============================================
  // PATEK PHILIPPE LIMITED EDITIONS
  // ============================================
  {
    id: 'pp-1',
    name: 'Nautilus 5711/1A Blue Dial',
    brand: 'Patek Philippe',
    price: 185000,
    description: 'The holy grail of modern watchmaking. The Nautilus 5711 with blue dial is the most sought-after timepiece in the world. Discontinued and extremely rare.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/4827-51887',
    reference: '5711/1A-010',
    condition: 'Pre-owned',
    year: 2022,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 26-330 SC',
    caseSize: '40mm',
    material: 'Stainless Steel',
    stock: 1,
    limitedEdition: true,
    limitedNumber: 'Discontinued',
    featured: true
  },
  {
    id: 'pp-2',
    name: 'Nautilus 5711/1R Rose Gold',
    brand: 'Patek Philippe',
    price: 285000,
    description: 'The final evolution of the 5711 in 18ct rose gold with brown sunburst dial. The ultimate statement piece.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/381929-51887',
    reference: '5711/1R-001',
    condition: 'Unworn',
    year: 2023,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 26-330 SC',
    caseSize: '40mm',
    material: '18ct Rose Gold',
    stock: 1,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'pp-3',
 name: 'Aquanaut 5167A Black Dial',
    brand: 'Patek Philippe',
    price: 85000,
    description: 'The "Tropical" Aquanaut with composite strap and stunning black dial. The perfect blend of sportiness and elegance.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/202472-51887',
    reference: '5167A-001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 324 SC',
    caseSize: '40.8mm',
    material: 'Stainless Steel',
    stock: 2,
    limitedEdition: false,
    featured: false
  },
  {
    id: 'pp-4',
    name: 'Aquanaut 5968A Chronograph',
    brand: 'Patek Philippe',
    price: 175000,
    description: 'The Aquanaut Chronograph with its distinctive orange accents. The ultimate sports chronograph for collectors.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/202154-51887',
    reference: '5968A-001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. CH 28-520 C',
    caseSize: '42.2mm',
    material: 'Stainless Steel',
    stock: 1,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'pp-5',
    name: 'Calatrava 5227G White Gold',
    brand: 'Patek Philippe',
    price: 45000,
    description: 'The officer\'s watch with hinged dust cover. A timeless classic that represents the essence of Patek Philippe.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/202401-51887',
    reference: '5227G-010',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 324 SC',
    caseSize: '39mm',
    material: '18ct White Gold',
    stock: 2,
    limitedEdition: false,
    featured: false
  },
  {
    id: 'pp-6',
    name: 'Nautilus 5740/1G Perpetual Calendar',
    brand: 'Patek Philippe',
    price: 285000,
    description: 'The Nautilus Perpetual Calendar in white gold. The most complicated Nautilus ever made, limited production.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/4827-51887',
    reference: '5740/1G-001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 240 Q',
    caseSize: '40mm',
    material: '18ct White Gold',
    stock: 0, // OUT OF STOCK - Set by dealer
    limitedEdition: true,
    featured: false
  },
  {
    id: 'pp-7',
    name: 'Grand Complications 5270P',
    brand: 'Patek Philippe',
    price: 385000,
    description: 'The perpetual calendar chronograph in platinum with salmon dial. One of the most prestigious complications in watchmaking.',
    image: 'https://patek-res.cloudinary.com/dfsmedia/0906caea301d42b3b8bd23bd656d1711/202327-51887',
    reference: '5270P-001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Manual Cal. CH 29-535 PS Q',
    caseSize: '41mm',
    material: 'Platinum',
    stock: 1,
    limitedEdition: true,
    featured: true
  },

  // ============================================
  // RICHARD MILLE LIMITED EDITIONS
  // ============================================
  {
    id: 'rm-1',
    name: 'RM 11-03 Flyback Chronograph',
    brand: 'Richard Mille',
    price: 485000,
    description: 'The RM 11-03 in NTPT carbon with its distinctive tonneau shape and flyback chronograph. A masterpiece of motorsport engineering.',
    image: 'https://www.ablogtowatch.com/wp-content/uploads/2019/04/Richard-Mille-RM-11-03-red-FQ-TPT-watch-2.jpg',
    reference: 'RM 11-03',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. RMAC3',
    caseSize: '49.94 x 44.50mm',
    material: 'Carbon TPT',
    stock: 1,
    limitedEdition: true,
    limitedNumber: 'Limited Production',
    featured: true
  },
  {
    id: 'rm-2',
    name: 'RM 67-02 Automatic',
    brand: 'Richard Mille',
    price: 285000,
    description: 'The ultra-thin RM 67-02 in Quartz TPT. The lightest automatic watch in the Richard Mille collection, inspired by sprinting.',
    image: 'https://italianwatchspotter.com/wp-content/uploads/2022/07/6654.jpg',
    reference: 'RM 67-02',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. CRMA7',
    caseSize: '38.7 x 47.52mm',
    material: 'Quartz TPT',
    stock: 2,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rm-3',
    name: 'RM 35-02 Rafael Nadal',
    brand: 'Richard Mille',
    price: 325000,
    description: 'The Rafael Nadal signature model in red Quartz TPT. Designed to withstand the extreme forces of professional tennis.',
    image: 'https://diamondsourcenyc.com/wp-content/uploads/2025/08/Richard-Mille-Automatic-Rafael-Nadal-Watch-RM-35-02.jpg',
    reference: 'RM 35-02',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. RMAL1',
    caseSize: '49.94 x 42.70mm',
    material: 'Red Quartz TPT',
    stock: 1,
    limitedEdition: true,
    limitedNumber: 'Player Edition',
    featured: true
  },
  {
    id: 'rm-4',
    name: 'RM 030 White Rush',
    brand: 'Richard Mille',
    price: 225000,
    description: 'The RM 030 with declutchable rotor in white ceramic and NTPT carbon. The perfect blend of innovation and elegance.',
    image: 'https://luxurywatchesusa.com/wp-content/uploads/2022/04/RM-030-white-rush.jpg',
    reference: 'RM 030',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. RMAR1',
    caseSize: '50mm x 42.7mm',
    material: 'White Ceramic & NTPT',
    stock: 2,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rm-5',
    name: 'RM 11-04 Roberto Mancini',
    brand: 'Richard Mille',
    price: 525000,
    description: 'The Roberto Mancini edition with dedicated football timer. Created for the Italian national team manager.',
    image: 'https://wp-aws-media.s3-accelerate.amazonaws.com/2019/12/RM11-04_MANCINI_34FRONT_BB-e1576228792355.jpg',
    reference: 'RM 11-04',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. RMAC3',
    caseSize: '49.94 x 44.50mm',
    material: 'Carbon TPT',
    stock: 0, // OUT OF STOCK - Set by dealer
    limitedEdition: true,
    limitedNumber: '17/50',
    featured: false
  },
  {
    id: 'rm-6',
    name: 'RM 72-01 Lifestyle Chronograph',
    brand: 'Richard Mille',
    price: 285000,
    description: 'The first in-house flyback chronograph from Richard Mille. The ultimate lifestyle chronograph for the modern collector.',
    image: 'https://revolutionwatch.com/wp-content/uploads/2020/09/24-Richard-Mille-RM-72-01-Lifestyle-Chronograph.jpg',
    reference: 'RM 72-01',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. CRMC1',
    caseSize: '38.4 x 47.34mm',
    material: 'Black Ceramic',
    stock: 1,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'rm-7',
    name: 'RM 88 Smiley Tourbillon',
    brand: 'Richard Mille',
    price: 1250000,
    description: 'The extraordinary Smiley edition with miniature sculpture on the dial. One of the most artistic watches ever created. Limited to 50 pieces worldwide.',
    image: 'https://hautetime.s3.us-west-1.amazonaws.com/wp-content/uploads/2022/09/27023006/rm-2.jpg',
    reference: 'RM 88',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Tourbillon Cal. CRMT7',
    caseSize: '48.15 x 39.74mm',
    material: 'White Gold & Carbon TPT',
    stock: 1,
    limitedEdition: true,
    limitedNumber: '23/50',
    featured: true
  },

  // ============================================
  // AUDEMARS PIGUET LIMITED EDITIONS
  // ============================================
  {
    id: 'ap-1',
    name: 'Royal Oak Jumbo Extra-Thin',
    brand: 'Audemars Piguet',
    price: 95000,
    description: 'The legendary 16202 Jumbo with "Petite Tapisserie" dial. The thinnest Royal Oak ever made, powered by the new Caliber 7121.',
    image: 'https://dynamicmedia.audemarspiguet.com/is/image/audemarspiguet/watch-668?size=1000,0&fmt=png-alpha&dpr=off',
    reference: '16202ST.OO.1240ST.01',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 7121',
    caseSize: '39mm',
    material: 'Stainless Steel',
    stock: 2,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'ap-2',
    name: 'Royal Oak Offshore Chronograph',
    brand: 'Audemars Piguet',
    price: 45000,
    description: 'The iconic Offshore chronograph with "Mega Tapisserie" dial and black ceramic bezel. The ultimate sports chronograph.',
    image: 'https://dynamicmedia.audemarspiguet.com/is/image/audemarspiguet/watch-1066?size=1000,0&fmt=png-alpha&dpr=off',
    reference: '26238CE.OO.1300CE.01',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 4404',
    caseSize: '42mm',
    material: 'Black Ceramic',
    stock: 3,
    limitedEdition: true,
    featured: false
  },
  {
    id: 'ap-3',
    name: 'Royal Oak Perpetual Calendar',
    brand: 'Audemars Piguet',
    price: 145000,
    description: 'The perpetual calendar with blue dial and platinum case. One of the most prestigious complications in the Royal Oak collection.',
    image: 'https://dynamicmedia.audemarspiguet.com/is/image/audemarspiguet/watch-668?size=1000,0&fmt=png-alpha&dpr=off',
    reference: '26574PT.OO.1220PT.01',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 5134',
    caseSize: '41mm',
    material: 'Platinum',
    stock: 1,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'ap-4',
    name: 'Royal Oak 50th Anniversary',
    brand: 'Audemars Piguet',
    price: 125000,
    description: 'The 50th Anniversary edition with special oscillating weight. A piece of horological history celebrating five decades of the Royal Oak.',
    image: 'https://dynamicmedia.audemarspiguet.com/is/image/audemarspiguet/watch-771?size=1000,0&fmt=png-alpha&dpr=off',
    reference: '15510ST.OO.1320ST.01',
    condition: 'Unworn',
    year: 2022,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 4302',
    caseSize: '41mm',
    material: 'Stainless Steel',
    stock: 0, // OUT OF STOCK - Set by dealer
    limitedEdition: true,
    limitedNumber: '50th Anniversary',
    featured: false
  },
  {
    id: 'ap-5',
    name: 'Code 11.59 Flying Tourbillon',
    brand: 'Audemars Piguet',
    price: 185000,
    description: 'The Code 11.59 flying tourbillon with smoked blue lacquered dial. Avant-garde design meets traditional watchmaking.',
    image: 'https://dynamicmedia.audemarspiguet.com/is/image/audemarspiguet/watch-771?size=1000,0&fmt=png-alpha&dpr=off',
    reference: '26396BC.OO.D321CR.01',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 2950',
    caseSize: '41mm',
    material: '18ct White Gold',
    stock: 1,
    limitedEdition: true,
    featured: false
  },

  // ============================================
  // OMEGA LIMITED EDITIONS
  // ============================================
  {
    id: 'omega-1',
    name: 'Speedmaster Moonwatch Professional',
    brand: 'Omega',
    price: 7800,
    description: 'The legendary Moonwatch with hesalite crystal and manual winding. The first watch worn on the moon, unchanged since 1969.',
    image: 'https://www.omegawatches.com/media/catalog/product/o/m/omega-speedmaster-moonwatch-professional-co-axial-master-chronometer-chronograph-42-mm-31030425001001-3ccf4a.png?w=1100',
    reference: '310.30.42.50.01.001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Manual Cal. 3861',
    caseSize: '42mm',
    material: 'Stainless Steel',
    stock: 5,
    limitedEdition: true,
    featured: true
  },
  {
    id: 'omega-2',
    name: 'Speedmaster Silver Snoopy Award',
    brand: 'Omega',
    price: 14500,
    description: 'The highly coveted Silver Snoopy Award 50th Anniversary edition with animated caseback. One of the most collectible Speedmasters.',
    image: 'https://www.omegawatches.com/media/catalog/product/o/m/omega-speedmaster-anniversary-series-co-axial-master-chronometer-chronograph-42-mm-31032425002001-d907dd.png?w=1100',
    reference: '310.32.42.50.02.001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Manual Cal. 3861',
    caseSize: '42mm',
    material: 'Stainless Steel',
    stock: 0, // OUT OF STOCK - Set by dealer
    limitedEdition: true,
    featured: false
  },
  {
    id: 'omega-3',
    name: 'Seamaster 300M James Bond 60th',
    brand: 'Omega',
    price: 9500,
    description: 'The 60th Anniversary James Bond edition with animated caseback featuring the iconic opening sequence. Limited to 7007 pieces.',
    image: 'https://www.omegawatches.com/media/catalog/product/o/m/omega-seamaster-diver-300m-co-axial-master-chronometer-42-mm-21030422003002-413ac2.png?w=1100',
    reference: '210.30.42.20.04.001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Automatic Cal. 8806',
    caseSize: '42mm',
    material: 'Stainless Steel',
    stock: 2,
    limitedEdition: true,
    limitedNumber: 'Limited 7007',
    featured: true
  },
  {
    id: 'omega-4',
    name: 'Speedmaster Chrono Chime',
    brand: 'Omega',
    price: 485000,
    description: 'The first ever chiming Speedmaster with Olympic Games tribute. One of the most complicated Omega watches ever made.',
    image: 'https://www.omegawatches.com/media/catalog/product/o/m/omega-speedmaster-chrono-chime-co-axial-master-chronometer-chronograph-45_mm-52250455203001-7ee7df.png?w=1100',
    reference: '522.50.45.52.03.001',
    condition: 'Unworn',
    year: 2024,
    originalBox: true,
    originalPapers: true,
    movement: 'Manual Cal. 1932',
    caseSize: '45mm',
    material: '18ct Sedna Gold',
    stock: 1,
    limitedEdition: true,
    featured: true
  }
];

// Stock Management Functions
export const getInStockWatches = () => luxuryWatches.filter(w => w.stock > 0);
export const getOutOfStockWatches = () => luxuryWatches.filter(w => w.stock === 0);
export const getFeaturedWatches = () => luxuryWatches.filter(w => w.featured && w.stock > 0);
export const getLimitedEditions = () => luxuryWatches.filter(w => w.limitedEdition && w.stock > 0);

// Update stock - Call this to modify inventory
export const updateStock = (watchId: string, newStock: number) => {
  const watch = luxuryWatches.find(w => w.id === watchId);
  if (watch) {
    watch.stock = Math.max(0, newStock);
  }
};

// Get stock status
export const getStockStatus = (watch: Watch) => {
  if (watch.stock === 0) return 'out-of-stock';
  if (watch.stock === 1) return 'last-one';
  if (watch.stock <= 3) return 'low-stock';
  return 'in-stock';
};

// Get unique brands
export const getBrands = () => ['All', ...Array.from(new Set(luxuryWatches.map(w => w.brand)))];

// Filter watches by availability
export const filterAvailableWatches = () => luxuryWatches.filter(w => w.stock > 0);