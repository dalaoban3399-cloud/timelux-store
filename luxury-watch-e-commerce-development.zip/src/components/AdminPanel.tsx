import React, { useState } from 'react';
import { 
  X, 
  Package, 
  AlertTriangle, 
  Check, 
  Search,
  Filter,
  TrendingUp,
  DollarSign,
  Box
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  luxuryWatches, 
  updateStock, 
  Watch 
} from '../data/watches';
import { watchFallbackImage } from '../utils/watchImage';

const handleImageError = (event: React.SyntheticEvent<HTMLImageElement>) => {
  const image = event.currentTarget;
  const currentSrc = image.getAttribute('src') || '';

  if (currentSrc.match(/\.jpe?g$/) && image.dataset.fallbackAttempted !== 'true') {
    image.dataset.fallbackAttempted = 'true';
    image.src = currentSrc.replace(/\.jpe?g$/, '.svg');
    return;
  }

  image.onerror = null;
  image.src = watchFallbackImage;
};

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [editingWatch, setEditingWatch] = useState<string | null>(null);
  const [tempStock, setTempStock] = useState<number>(0);

  const brands = ['All', ...Array.from(new Set(luxuryWatches.map(w => w.brand)))];

  // Filter watches
  const filteredWatches = luxuryWatches.filter(watch => {
    const matchesSearch = watch.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         watch.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         watch.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === 'All' || watch.brand === selectedBrand;
    const matchesStatus = selectedStatus === 'All' || 
                         (selectedStatus === 'in-stock' && watch.stock > 0) ||
                         (selectedStatus === 'out-of-stock' && watch.stock === 0) ||
                         (selectedStatus === 'low-stock' && watch.stock > 0 && watch.stock <= 3);
    
    return matchesSearch && matchesBrand && matchesStatus;
  });

  const handleEditStock = (watch: Watch) => {
    setEditingWatch(watch.id);
    setTempStock(watch.stock);
  };

  const handleSaveStock = (watchId: string) => {
    updateStock(watchId, tempStock);
    setEditingWatch(null);
  };

  const handleCancelEdit = () => {
    setEditingWatch(null);
    setTempStock(0);
  };

  // Statistics
  const totalWatches = luxuryWatches.length;
  const inStockCount = luxuryWatches.filter(w => w.stock > 0).length;
  const outOfStockCount = luxuryWatches.filter(w => w.stock === 0).length;
  const totalValue = luxuryWatches.reduce((sum, w) => sum + (w.price * w.stock), 0);

  const getStockStatusColor = (stock: number) => {
    if (stock === 0) return 'bg-red-500/20 text-red-400 border-red-500/50';
    if (stock === 1) return 'bg-amber-500/20 text-amber-400 border-amber-500/50';
    if (stock <= 3) return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
    return 'bg-green-500/20 text-green-400 border-green-500/50';
  };

  const getStockStatusText = (stock: number) => {
    if (stock === 0) return 'Out of Stock';
    if (stock === 1) return 'Last One!';
    if (stock <= 3) return 'Low Stock';
    return 'In Stock';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-4 md:inset-8 lg:inset-12 bg-gray-900 rounded-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-800 flex items-center justify-between bg-gray-900/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">Inventory Management</h2>
                  <p className="text-sm text-gray-400">Manage your watch collection stock</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Stats Dashboard */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 border-b border-gray-800 bg-gray-800/30">
              <div className="p-4 bg-gray-800 rounded-xl">
                <div className="flex items-center gap-2 text-gray-400 mb-2">
                  <Box className="w-4 h-4" />
                  <span className="text-sm">Total Watches</span>
                </div>
                <p className="text-2xl font-bold text-white">{totalWatches}</p>
              </div>
              <div className="p-4 bg-gray-800 rounded-xl">
                <div className="flex items-center gap-2 text-green-400 mb-2">
                  <Check className="w-4 h-4" />
                  <span className="text-sm">In Stock</span>
                </div>
                <p className="text-2xl font-bold text-green-400">{inStockCount}</p>
              </div>
              <div className="p-4 bg-gray-800 rounded-xl">
                <div className="flex items-center gap-2 text-red-400 mb-2">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="text-sm">Out of Stock</span>
                </div>
                <p className="text-2xl font-bold text-red-400">{outOfStockCount}</p>
              </div>
              <div className="p-4 bg-gray-800 rounded-xl">
                <div className="flex items-center gap-2 text-amber-400 mb-2">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm">Inventory Value</span>
                </div>
                <p className="text-2xl font-bold text-amber-400">{formatCurrency(totalValue)}</p>
              </div>
            </div>

            {/* Filters */}
            <div className="p-6 border-b border-gray-800 space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Search watches, references, brands..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                </div>
                
                {/* Brand Filter */}
                <div className="relative">
                  <Filter className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <select
                    value={selectedBrand}
                    onChange={(e) => setSelectedBrand(e.target.value)}
                    className="pl-10 pr-8 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-amber-500 transition-colors appearance-none cursor-pointer"
                  >
                    {brands.map(brand => (
                      <option key={brand} value={brand}>{brand}</option>
                    ))}
                  </select>
                </div>

                {/* Status Filter */}
                <div className="relative">
                  <TrendingUp className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="pl-10 pr-8 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-amber-500 transition-colors appearance-none cursor-pointer"
                  >
                    <option value="All">All Status</option>
                    <option value="in-stock">In Stock</option>
                    <option value="low-stock">Low Stock (≤3)</option>
                    <option value="out-of-stock">Out of Stock</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Inventory List */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-3">
                {filteredWatches.map((watch) => (
                  <div
                    key={watch.id}
                    className={`p-4 rounded-xl border transition-all ${
                      watch.stock === 0 
                        ? 'bg-red-900/10 border-red-900/30 opacity-75' 
                        : 'bg-gray-800 border-gray-700'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      {/* Image */}
                      <img
                        src={watch.image}
                        alt={watch.name}
                        onError={handleImageError}
                        className="w-16 h-16 object-contain bg-gray-950 rounded-lg"
                      />
                      
                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-medium text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                            {watch.brand}
                          </span>
                          {watch.limitedEdition && (
                            <span className="text-xs font-medium text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded">
                              Limited
                            </span>
                          )}
                          {watch.limitedNumber && (
                            <span className="text-xs font-medium text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">
                              {watch.limitedNumber}
                            </span>
                          )}
                        </div>
                        <h3 className="font-semibold text-white truncate">{watch.name}</h3>
                        <p className="text-sm text-gray-500">Ref. {watch.reference}</p>
                      </div>

                      {/* Price */}
                      <div className="text-right hidden md:block">
                        <p className="font-bold text-amber-400">{formatCurrency(watch.price)}</p>
                        <p className="text-xs text-gray-500">{watch.year}</p>
                      </div>

                      {/* Stock Status */}
                      <div className="hidden sm:block">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${getStockStatusColor(watch.stock)}`}>
                          {watch.stock === 0 && <AlertTriangle className="w-3 h-3" />}
                          {getStockStatusText(watch.stock)}
                        </span>
                      </div>

                      {/* Stock Management */}
                      <div className="flex items-center gap-2">
                        {editingWatch === watch.id ? (
                          <>
                            <input
                              type="number"
                              min="0"
                              value={tempStock}
                              onChange={(e) => setTempStock(parseInt(e.target.value) || 0)}
                              className="w-16 px-2 py-2 bg-gray-700 border border-gray-600 rounded-lg text-center text-white focus:outline-none focus:border-amber-500"
                            />
                            <button
                              onClick={() => handleSaveStock(watch.id)}
                              className="p-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-2 bg-gray-600 hover:bg-gray-500 text-white rounded-lg transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        ) : (
                          <div className="flex items-center gap-3">
                            <span className="text-2xl font-bold text-white w-12 text-center">
                              {watch.stock}
                            </span>
                            <button
                              onClick={() => handleEditStock(watch)}
                              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white text-sm font-medium rounded-lg transition-colors"
                            >
                              Edit
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {filteredWatches.length === 0 && (
                  <div className="text-center py-12">
                    <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No watches found matching your criteria</p>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-gray-800 bg-gray-900/50 text-center text-sm text-gray-500">
              Stock Management Panel • {filteredWatches.length} watches displayed
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};