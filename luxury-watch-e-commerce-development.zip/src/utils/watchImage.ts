type WatchShape = 'round' | 'nautilus' | 'royal-oak' | 'tonneau';

const escapeSvgText = (value: string) =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

export const makeWatchImage = (
  brand: string,
  model: string,
  variant: string,
  primary = '#111827',
  accent = '#f59e0b',
  shape: WatchShape = 'round'
) => {
  const safeBrand = escapeSvgText(brand.toUpperCase());
  const safeModel = escapeSvgText(model.toUpperCase());
  const safeVariant = escapeSvgText(variant.toUpperCase());

  const roundCase = `
    <circle cx="400" cy="400" r="220" fill="url(#metal)" filter="url(#shadow)"/>
    <circle cx="400" cy="400" r="198" fill="#050505"/>
    <circle cx="400" cy="400" r="175" fill="${primary}"/>
  `;

  const nautilusCase = `
    <ellipse cx="400" cy="400" rx="245" ry="190" fill="url(#metal)" filter="url(#shadow)" transform="rotate(-30 400 400)"/>
    <ellipse cx="400" cy="400" rx="220" ry="170" fill="#050505" transform="rotate(-30 400 400)"/>
    <ellipse cx="400" cy="400" rx="195" ry="150" fill="${primary}" transform="rotate(-30 400 400)"/>
  `;

  const royalOakCase = `
    <polygon points="400,145 525,197 585,322 585,478 525,603 400,655 275,603 215,478 215,322 275,197" fill="url(#metal)" filter="url(#shadow)"/>
    <polygon points="400,175 505,220 555,335 555,465 505,580 400,625 295,580 245,465 245,335 295,220" fill="#050505"/>
    <polygon points="400,205 485,242 530,350 530,450 485,558 400,595 315,558 270,450 270,350 315,242" fill="${primary}"/>
  `;

  const tonneauCase = `
    <path d="M248,195 Q400,142 552,195 L608,400 Q400,700 192,400 Z" fill="url(#metal)" filter="url(#shadow)"/>
    <path d="M270,225 Q400,182 530,225 L575,400 Q400,655 225,400 Z" fill="#050505"/>
    <path d="M292,252 Q400,218 508,252 L545,400 Q400,615 255,400 Z" fill="${primary}"/>
  `;

  const caseMarkup = {
    round: roundCase,
    nautilus: nautilusCase,
    'royal-oak': royalOakCase,
    tonneau: tonneauCase,
  }[shape];

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#050505"/>
        <stop offset="100%" stop-color="#1f2937"/>
      </linearGradient>
      <linearGradient id="metal" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#f3f4f6"/>
        <stop offset="45%" stop-color="#9ca3af"/>
        <stop offset="100%" stop-color="#4b5563"/>
      </linearGradient>
      <filter id="shadow" x="-40%" y="-40%" width="180%" height="180%">
        <feDropShadow dx="0" dy="22" stdDeviation="24" flood-color="#000000" flood-opacity="0.55"/>
      </filter>
      <pattern id="texture" width="38" height="38" patternUnits="userSpaceOnUse">
        <path d="M0 19 H38 M19 0 V38" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
      </pattern>
    </defs>
    <rect width="800" height="800" fill="url(#bg)"/>
    <circle cx="400" cy="400" r="310" fill="rgba(245,158,11,0.08)"/>
    ${caseMarkup}
    <circle cx="400" cy="400" r="125" fill="url(#texture)" opacity="0.55"/>
    <g stroke="${accent}" stroke-linecap="round">
      <line x1="400" y1="400" x2="400" y2="292" stroke-width="7"/>
      <line x1="400" y1="400" x2="482" y2="400" stroke-width="5"/>
      <line x1="400" y1="400" x2="355" y2="485" stroke-width="2" opacity="0.7"/>
    </g>
    <circle cx="400" cy="400" r="12" fill="${accent}"/>
    <g fill="${accent}" opacity="0.92">
      <rect x="394" y="246" width="12" height="32" rx="6"/>
      <rect x="394" y="522" width="12" height="32" rx="6"/>
      <rect x="246" y="394" width="32" height="12" rx="6"/>
      <rect x="522" y="394" width="32" height="12" rx="6"/>
    </g>
    <text x="400" y="348" font-family="Georgia, serif" font-size="18" fill="${accent}" text-anchor="middle" letter-spacing="4" font-weight="700">${safeBrand}</text>
    <text x="400" y="505" font-family="Arial, sans-serif" font-size="23" fill="#ffffff" text-anchor="middle" font-weight="800" letter-spacing="2">${safeModel}</text>
    <text x="400" y="535" font-family="Arial, sans-serif" font-size="13" fill="#cbd5e1" text-anchor="middle" letter-spacing="2">${safeVariant}</text>
  </svg>`;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
};

export const watchFallbackImage = makeWatchImage('TimeLux', 'Official Image', 'Coming Soon');