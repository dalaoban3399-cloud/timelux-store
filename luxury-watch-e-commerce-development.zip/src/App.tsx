import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { 
  ShoppingBag, 
  X, 
  ChevronRight, 
  Shield, 
  CreditCard, 
  Lock,
  Check,
  Clock,
  Award,
  Star,
  ArrowRight,
  Settings,
  AlertTriangle,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { luxuryWatches, Watch, getBrands, getFeaturedWatches, filterAvailableWatches } from './data/watches';
import { AdminPanel } from './components/AdminPanel';
import { watchFallbackImage } from './utils/watchImage';

// Initialize Stripe with your publishable key
// @ts-ignore - Vite environment variables
const stripeKey = import.meta.env?.VITE_STRIPE_PUBLIC_KEY || 'pk_test_placeholder';
const stripePromise = loadStripe(stripeKey);

// Cart Item Type
interface CartItem extends Watch {
  quantity: number;
}

// Format currency
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

const handleImageError = (event: React.SyntheticEvent<HTMLImageElement>) => {
  const image = event.currentTarget;
  const currentSrc = image.getAttribute('src') || '';

  if (currentSrc.match(/\.jpe?g$/) && image.dataset.fallbackAttempted !== 'true') {
    image.dataset.fallbackAttempted = 'true';
    image.src = currentSrc.replace(/\.jpe?g$/, '.svg');
    return;
  }

  image.onerror = null;
  image.src = watchFallbackImage;
};

// Checkout Form Component with 3D Secure
interface CheckoutFormProps {
  clientSecret: string;
  onSuccess: () => void;
  total: number;
  cartItems: CartItem[];
}

const CheckoutForm: React.FC<CheckoutFormProps> = ({ onSuccess, total }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [billingDetails, setBillingDetails] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    country: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    if (!billingDetails.name || !billingDetails.email || !billingDetails.phone) {
      setMessage('Please fill in all required billing details.');
      return;
    }

    setIsLoading(true);
    setMessage(null);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/payment-complete`,
          payment_method_data: {
            billing_details: {
              name: billingDetails.name,
              email: billingDetails.email,
              phone: billingDetails.phone,
              address: {
                line1: billingDetails.address,
                city: billingDetails.city,
                postal_code: billingDetails.postalCode,
                country: billingDetails.country,
              },
            },
          },
        },
        redirect: 'if_required',
      });

      if (error) {
        if (error.type === 'card_error' || error.type === 'validation_error') {
          setMessage(error.message || 'An error occurred with your payment.');
        } else {
          setMessage('An unexpected error occurred.');
        }
      } else if (paymentIntent) {
        switch (paymentIntent.status) {
          case 'succeeded':
            setMessage('Payment successful!');
            onSuccess();
            break;
          case 'processing':
            setMessage('Your payment is processing.');
            break;
          case 'requires_action':
            break;
          case 'requires_payment_method':
            setMessage('Your payment was not successful, please try again.');
            break;
          default:
            setMessage('Something went wrong.');
            break;
        }
      }
    } catch (err) {
      setMessage('An unexpected error occurred. Please try again.');
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Billing Details</h3>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Full Name *</label>
            <input
              type="text"
              value={billingDetails.name}
              onChange={(e) => setBillingDetails({ ...billingDetails, name: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
              placeholder="John Doe"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Email *</label>
            <input
              type="email"
              value={billingDetails.email}
              onChange={(e) => setBillingDetails({ ...billingDetails, email: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
              placeholder="john@example.com"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Phone Number *</label>
          <input
            type="tel"
            value={billingDetails.phone}
            onChange={(e) => setBillingDetails({ ...billingDetails, phone: e.target.value })}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
            placeholder="+1 (555) 123-4567"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Street Address</label>
          <input
            type="text"
            value={billingDetails.address}
            onChange={(e) => setBillingDetails({ ...billingDetails, address: e.target.value })}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
            placeholder="123 Main Street"
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">City</label>
            <input
              type="text"
              value={billingDetails.city}
              onChange={(e) => setBillingDetails({ ...billingDetails, city: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
              placeholder="New York"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Postal Code</label>
            <input
              type="text"
              value={billingDetails.postalCode}
              onChange={(e) => setBillingDetails({ ...billingDetails, postalCode: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition-colors"
              placeholder="10001"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Country</label>
            <select
              value={billingDetails.country}
              onChange={(e) => setBillingDetails({ ...billingDetails, country: e.target.value })}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-amber-500 transition-colors"
            >
              <option value="">Select</option>
              <option value="US">United States</option>
              <option value="UK">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="AU">Australia</option>
              <option value="DE">Germany</option>
              <option value="FR">France</option>
              <option value="CH">Switzerland</option>
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Card Details</h3>
        <div className="p-4 bg-gray-800 border border-gray-700 rounded-lg">
          <PaymentElement options={{ layout: 'tabs' }} />
        </div>
      </div>

      <div className="flex items-center gap-3 p-4 bg-green-900/20 border border-green-800 rounded-lg">
        <Shield className="w-5 h-5 text-green-400 flex-shrink-0" />
        <div className="text-sm text-green-300">
          <span className="font-semibold">3D Secure Protected:</span> This transaction requires authentication with your bank for added security.
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-lg ${message.includes('successful') ? 'bg-green-900/30 border border-green-700 text-green-300' : 'bg-red-900/30 border border-red-700 text-red-300'}`}>
          {message}
        </div>
      )}

      <button
        type="submit"
        disabled={!stripe || isLoading}
        className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-gray-900 font-bold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-gray-900/30 border-t-gray-900 rounded-full animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <Lock className="w-5 h-5" />
            Pay {formatCurrency(total)}
          </>
        )}
      </button>

      <div className="flex items-center justify-center gap-6 text-gray-500">
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          <span className="text-xs">Visa</span>
        </div>
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          <span className="text-xs">Mastercard</span>
        </div>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          <span className="text-xs">3D Secure</span>
        </div>
      </div>
    </form>
  );
};

// Main App Component
function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isWixGuideOpen, setIsWixGuideOpen] = useState(false);
  const [selectedWatch, setSelectedWatch] = useState<Watch | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [clientSecret, setClientSecret] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  const [showOnlyAvailable, setShowOnlyAvailable] = useState(true);

  // Get available watches
  const allWatches = showOnlyAvailable ? filterAvailableWatches() : luxuryWatches;
  const brands = getBrands();
  
  const filteredWatches = selectedBrand === 'All' 
    ? allWatches 
    : allWatches.filter(w => w.brand === selectedBrand);

  const featuredWatches = getFeaturedWatches().filter(w => w.stock > 0);

  // Cart functions
  const addToCart = (watch: Watch) => {
    if (watch.stock === 0) return;
    
    setCart(prev => {
      const existing = prev.find(item => item.id === watch.id);
      if (existing) {
        return prev.map(item =>
          item.id === watch.id
            ? { ...item, quantity: Math.min(item.quantity + 1, watch.stock) }
            : item
        );
      }
      return [...prev, { ...watch, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (watchId: string) => {
    setCart(prev => prev.filter(item => item.id !== watchId));
  };

  const updateQuantity = (watchId: string, quantity: number) => {
    const watch = luxuryWatches.find(w => w.id === watchId);
    if (!watch) return;
    
    if (quantity <= 0) {
      removeFromCart(watchId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === watchId ? { ...item, quantity: Math.min(quantity, watch.stock) } : item
      )
    );
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const initializeCheckout = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: cartTotal,
          currency: 'usd',
          items: cart.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
          }))
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to initialize payment');
      }

      const data = await response.json();
      setClientSecret(data.clientSecret);
      setCheckoutStep('checkout');
    } catch (error) {
      console.error('Error initializing checkout:', error);
      setClientSecret('pi_demo_secret_placeholder');
      setCheckoutStep('checkout');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePaymentSuccess = () => {
    setCheckoutStep('success');
    setCart([]);
  };

  const getStockStatusColor = (stock: number) => {
    if (stock === 0) return 'bg-red-500/20 text-red-400 border-red-500/50';
    if (stock === 1) return 'bg-amber-500/20 text-amber-400 border-amber-500/50';
    if (stock <= 3) return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
    return 'bg-green-500/20 text-green-400 border-green-500/50';
  };

  const getStockStatusText = (stock: number) => {
    if (stock === 0) return 'Out of Stock';
    if (stock === 1) return 'Last One!';
    if (stock <= 3) return `Only ${stock} left`;
    return `${stock} available`;
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2">
              <Award className="w-8 h-8 text-amber-500" />
              <span className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                TimeLux
              </span>
            </div>
            
            <nav className="hidden md:flex items-center gap-8">
              <a href="#collections" className="text-gray-300 hover:text-white transition-colors">Collections</a>
              <a href="#brands" className="text-gray-300 hover:text-white transition-colors">Brands</a>
              <a href="#limited" className="text-gray-300 hover:text-white transition-colors">Limited Editions</a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">Contact</a>
            </nav>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsWixGuideOpen(true)}
                className="px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold rounded-full hover:from-purple-500 hover:to-indigo-500 transition-all flex items-center gap-1 shadow-sm"
                title="Publish to Wix Instructions"
              >
                <Sparkles className="w-3 h-3" />
                Publish to Wix
              </button>
              <button
                onClick={() => setIsAdminOpen(true)}
                className="p-2 text-gray-400 hover:text-white transition-colors"
                title="Inventory Management"
              >
                <Settings className="w-5 h-5" />
              </button>
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-gray-300 hover:text-white transition-colors"
              >
                <ShoppingBag className="w-6 h-6" />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-500 text-gray-900 text-xs font-bold rounded-full flex items-center justify-center">
                    {cart.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-950 to-gray-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(251,191,36,0.1),transparent_50%)]" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
                Exceptional
              </span>
              <br />
              <span className="bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                Timepieces
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10">
              Discover our curated collection of rare and limited edition luxury watches from Rolex, 
              Patek Philippe, Richard Mille, and more. Each timepiece is authenticated with original box and papers.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={() => document.getElementById('collections')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-gray-900 font-bold rounded-full hover:from-amber-400 hover:to-amber-500 transition-all duration-300 flex items-center gap-2"
              >
                Explore Collection
                <ArrowRight className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 text-gray-400">
                <Shield className="w-5 h-5 text-green-400" />
                <span>3D Secure Protected</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Watches */}
      <section className="py-16 bg-gray-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-8">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <h2 className="text-2xl font-bold">Featured Limited Editions</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredWatches.slice(0, 3).map((watch, index) => (
              <motion.div
                key={watch.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group bg-gray-800 rounded-2xl overflow-hidden border border-gray-700 hover:border-amber-500/50 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedWatch(watch)}
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={watch.image}
                    alt={watch.name}
                    onError={handleImageError}
                    className="w-full h-full object-contain p-5 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent" />
                  {watch.limitedNumber && (
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-purple-500 text-white text-xs font-bold rounded-full">
                        {watch.limitedNumber}
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-xs text-amber-400 mb-1">{watch.brand}</p>
                  <h3 className="font-bold text-white mb-2">{watch.name}</h3>
                  <p className="text-amber-400 font-bold">{formatCurrency(watch.price)}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Filter */}
      <section id="brands" className="py-8 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center gap-4 justify-between mb-6">
            <h2 className="text-2xl font-bold">Our Collection</h2>
            <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
              <input
                type="checkbox"
                checked={showOnlyAvailable}
                onChange={(e) => setShowOnlyAvailable(e.target.checked)}
                className="w-4 h-4 rounded border-gray-600 bg-gray-700 text-amber-500 focus:ring-amber-500"
              />
              Show available watches only
            </label>
          </div>
          <div className="flex items-center gap-3 overflow-x-auto pb-2">
            {brands.map(brand => (
              <button
                key={brand}
                onClick={() => setSelectedBrand(brand)}
                className={`px-6 py-3 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  selectedBrand === brand
                    ? 'bg-amber-500 text-gray-900'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {brand}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Watch Collection */}
      <section id="collections" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <p className="text-gray-400">
              Showing {filteredWatches.length} {filteredWatches.length === 1 ? 'watch' : 'watches'}
              {selectedBrand !== 'All' && ` from ${selectedBrand}`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredWatches.map((watch, index) => (
              <motion.div
                key={watch.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className={`group bg-gray-900 rounded-2xl overflow-hidden border transition-all duration-300 ${
                  watch.stock === 0 
                    ? 'border-gray-800 opacity-60' 
                    : 'border-gray-800 hover:border-amber-500/50'
                }`}
              >
                <div 
                  className="relative aspect-square overflow-hidden cursor-pointer"
                  onClick={() => setSelectedWatch(watch)}
                >
                  <img
                    src={watch.image}
                    alt={watch.name}
                    onError={handleImageError}
                    className="w-full h-full object-contain p-5 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent opacity-60" />
                  
                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    <span className="px-3 py-1 bg-amber-500 text-gray-900 text-xs font-bold rounded-full">
                      {watch.brand}
                    </span>
                    {watch.limitedEdition && watch.stock > 0 && (
                      <span className="px-3 py-1 bg-purple-500/90 text-white text-xs font-bold rounded-full flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Limited
                      </span>
                    )}
                  </div>

                  {/* Stock Status */}
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 text-xs font-bold rounded-full border ${getStockStatusColor(watch.stock)}`}>
                      {watch.stock === 0 ? 'Sold Out' : watch.condition}
                    </span>
                  </div>

                  {/* Out of Stock Overlay */}
                  {watch.stock === 0 && (
                    <div className="absolute inset-0 bg-gray-950/80 flex items-center justify-center">
                      <div className="text-center">
                        <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-2" />
                        <p className="text-red-400 font-bold">Out of Stock</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                      {watch.name}
                    </h3>
                  </div>
                  <p className="text-sm text-gray-500 mb-3">Ref. {watch.reference}</p>
                  
                  <div className="flex items-center gap-3 text-xs text-gray-400 mb-4">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {watch.year}
                    </span>
                    <span className="flex items-center gap-1">
                      <Award className="w-3 h-3" />
                      {watch.caseSize}
                    </span>
                  </div>

                  {/* Stock Indicator */}
                  <div className="mb-4">
                    <span className={`text-xs font-medium ${
                      watch.stock === 0 ? 'text-red-400' : 
                      watch.stock <= 3 ? 'text-amber-400' : 'text-green-400'
                    }`}>
                      {getStockStatusText(watch.stock)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-800">
                    <span className="text-xl font-bold text-amber-400">
                      {formatCurrency(watch.price)}
                    </span>
                    <button
                      onClick={() => addToCart(watch)}
                      disabled={watch.stock === 0}
                      className="px-4 py-2 bg-gray-800 hover:bg-amber-500 disabled:bg-gray-800 disabled:text-gray-600 disabled:cursor-not-allowed hover:text-gray-900 text-white text-sm font-medium rounded-lg transition-all duration-300 flex items-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      {watch.stock === 0 ? 'Sold Out' : 'Add'}
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredWatches.length === 0 && (
            <div className="text-center py-16">
              <AlertTriangle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 text-lg">No watches available in this category</p>
              <button
                onClick={() => { setSelectedBrand('All'); setShowOnlyAvailable(false); }}
                className="mt-4 text-amber-400 hover:text-amber-300 font-medium"
              >
                View all watches
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-16 bg-gray-900/50 border-y border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: '3D Secure', desc: 'Bank-level authentication' },
              { icon: Check, title: 'Authenticated', desc: 'Expert verification' },
              { icon: Award, title: 'Original Papers', desc: 'Box & papers included' },
              { icon: Star, title: '5-Star Service', desc: 'Premium support' },
            ].map((badge, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center">
                  <badge.icon className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">{badge.title}</h4>
                  <p className="text-sm text-gray-400">{badge.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Award className="w-8 h-8 text-amber-500" />
                <span className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                  TimeLux
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                Your trusted destination for authentic luxury timepieces. 
                Every watch is authenticated and comes with original documentation.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Collections</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Rolex</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Patek Philippe</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Richard Mille</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Audemars Piguet</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shipping Info</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Returns</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Payment Security</h4>
              <div className="flex items-center gap-2 text-gray-400 mb-4">
                <Shield className="w-5 h-5 text-green-400" />
                <span className="text-sm">3D Secure Authentication</span>
              </div>
              <p className="text-sm text-gray-500">
                All transactions are protected with bank-level 3D Secure authentication.
              </p>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
            © 2024 TimeLux. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Admin Panel */}
      <AdminPanel isOpen={isAdminOpen} onClose={() => setIsAdminOpen(false)} />

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
              onClick={() => setIsCartOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-lg bg-gray-900 border-l border-gray-800 z-50 overflow-hidden flex flex-col"
            >
              {/* Cart Header */}
              <div className="p-6 border-b border-gray-800 flex items-center justify-between">
                <h2 className="text-xl font-bold">
                  {checkoutStep === 'cart' && 'Shopping Cart'}
                  {checkoutStep === 'checkout' && 'Secure Checkout'}
                  {checkoutStep === 'success' && 'Order Confirmed'}
                </h2>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setCheckoutStep('cart');
                  }}
                  className="p-2 text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Cart Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {checkoutStep === 'cart' && (
                  <>
                    {cart.length === 0 ? (
                      <div className="text-center py-12">
                        <ShoppingBag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                        <p className="text-gray-400">Your cart is empty</p>
                        <button
                          onClick={() => setIsCartOpen(false)}
                          className="mt-4 text-amber-400 hover:text-amber-300 font-medium"
                        >
                          Continue Shopping
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {cart.map(item => (
                          <div key={item.id} className="flex gap-4 p-4 bg-gray-800/50 rounded-xl">
                            <img
                              src={item.image}
                              alt={item.name}
                              onError={handleImageError}
                              className="w-24 h-24 object-contain bg-gray-950 rounded-lg"
                            />
                            <div className="flex-1">
                              <div className="flex items-start justify-between mb-1">
                                <h3 className="font-semibold text-white">{item.name}</h3>
                                <button
                                  onClick={() => removeFromCart(item.id)}
                                  className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                              <p className="text-sm text-gray-500 mb-2">{item.brand}</p>
                              <p className="text-amber-400 font-bold mb-3">
                                {formatCurrency(item.price)}
                              </p>
                              <div className="flex items-center gap-3">
                                <button
                                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                  className="w-8 h-8 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <button
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                  className="w-8 h-8 bg-gray-700 hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                {checkoutStep === 'checkout' && clientSecret && (
                  <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <CheckoutForm
                      clientSecret={clientSecret}
                      onSuccess={handlePaymentSuccess}
                      total={cartTotal}
                      cartItems={cart}
                    />
                  </Elements>
                )}

                {checkoutStep === 'checkout' && !clientSecret && (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mb-4">
                      <CreditCard className="w-8 h-8 text-amber-400" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Payment Setup</h3>
                    <p className="text-gray-400 mb-6 max-w-sm">
                      To enable real payments, configure your Stripe keys in the environment variables.
                    </p>
                    <div className="space-y-3 w-full max-w-sm">
                      <div className="p-4 bg-gray-800 rounded-lg text-left">
                        <p className="text-sm text-gray-400 mb-2">Demo Total:</p>
                        <p className="text-2xl font-bold text-amber-400">{formatCurrency(cartTotal)}</p>
                      </div>
                      <button
                        onClick={() => setCheckoutStep('cart')}
                        className="w-full py-3 bg-gray-800 hover:bg-gray-700 text-white font-medium rounded-lg transition-colors"
                      >
                        Back to Cart
                      </button>
                      <button
                        onClick={handlePaymentSuccess}
                        className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-gray-900 font-bold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all"
                      >
                        Simulate Successful Payment
                      </button>
                    </div>
                  </div>
                )}

                {checkoutStep === 'success' && (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Check className="w-10 h-10 text-green-400" />
                    </div>
                    <h3 className="text-2xl font-bold mb-4">Payment Successful!</h3>
                    <p className="text-gray-400 mb-6">
                      Thank you for your purchase. Your order has been confirmed and you will receive a confirmation email shortly.
                    </p>
                    <div className="p-4 bg-gray-800 rounded-lg mb-6">
                      <p className="text-sm text-gray-400">Order Total</p>
                      <p className="text-xl font-bold text-amber-400">{formatCurrency(cartTotal)}</p>
                    </div>
                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        setCheckoutStep('cart');
                      }}
                      className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-gray-900 font-bold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all"
                    >
                      Continue Shopping
                    </button>
                  </div>
                )}
              </div>

              {/* Cart Footer */}
              {checkoutStep === 'cart' && cart.length > 0 && (
                <div className="p-6 border-t border-gray-800 bg-gray-900">
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between text-gray-400">
                      <span>Subtotal</span>
                      <span>{formatCurrency(cartTotal)}</span>
                    </div>
                    <div className="flex items-center justify-between text-gray-400">
                      <span>Shipping</span>
                      <span>Free</span>
                    </div>
                    <div className="flex items-center justify-between text-lg font-bold pt-3 border-t border-gray-800">
                      <span>Total</span>
                      <span className="text-amber-400">{formatCurrency(cartTotal)}</span>
                    </div>
                  </div>
                  <button
                    onClick={initializeCheckout}
                    disabled={isLoading}
                    className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-gray-900 font-bold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-gray-900/30 border-t-gray-900 rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        Proceed to Checkout
                        <ChevronRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs text-gray-500 mt-4 flex items-center justify-center gap-2">
                    <Lock className="w-3 h-3" />
                    Secured by 3D Secure Authentication
                  </p>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Watch Detail Modal */}
      <AnimatePresence>
        {selectedWatch && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
              onClick={() => setSelectedWatch(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-4 md:inset-12 lg:inset-20 bg-gray-900 rounded-2xl z-50 overflow-hidden flex flex-col md:flex-row"
            >
              <button
                onClick={() => setSelectedWatch(null)}
                className="absolute top-4 right-4 z-10 p-2 bg-gray-800/80 rounded-full text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="md:w-1/2 h-64 md:h-full">
                <img
                  src={selectedWatch.image}
                  alt={selectedWatch.name}
                  onError={handleImageError}
                  className="w-full h-full object-contain bg-gray-950 p-8"
                />
              </div>

              <div className="md:w-1/2 p-6 md:p-10 overflow-y-auto">
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="inline-block px-3 py-1 bg-amber-500/20 text-amber-400 text-sm font-bold rounded-full">
                      {selectedWatch.brand}
                    </span>
                    {selectedWatch.limitedEdition && (
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-400 text-sm font-bold rounded-full flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Limited Edition
                      </span>
                    )}
                  </div>
                  <h2 className="text-3xl font-bold mb-2">{selectedWatch.name}</h2>
                  <p className="text-gray-500">Reference: {selectedWatch.reference}</p>
                </div>

                <p className="text-gray-300 mb-8 leading-relaxed">
                  {selectedWatch.description}
                </p>

                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Condition</p>
                    <p className="font-semibold">{selectedWatch.condition}</p>
                  </div>
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Year</p>
                    <p className="font-semibold">{selectedWatch.year}</p>
                  </div>
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Movement</p>
                    <p className="font-semibold">{selectedWatch.movement}</p>
                  </div>
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Case Size</p>
                    <p className="font-semibold">{selectedWatch.caseSize}</p>
                  </div>
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Material</p>
                    <p className="font-semibold">{selectedWatch.material}</p>
                  </div>
                  <div className="p-4 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Stock Status</p>
                    <p className={`font-semibold flex items-center gap-2 ${
                      selectedWatch.stock === 0 ? 'text-red-400' : 'text-green-400'
                    }`}>
                      {selectedWatch.stock === 0 ? (
                        <><AlertTriangle className="w-4 h-4" /> Out of Stock</>
                      ) : (
                        <><Check className="w-4 h-4" /> {getStockStatusText(selectedWatch.stock)}</>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-6 border-t border-gray-800">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Price</p>
                    <p className="text-3xl font-bold text-amber-400">
                      {formatCurrency(selectedWatch.price)}
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      if (selectedWatch.stock > 0) {
                        addToCart(selectedWatch);
                        setSelectedWatch(null);
                      }
                    }}
                    disabled={selectedWatch.stock === 0}
                    className="px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 disabled:from-gray-700 disabled:to-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed text-gray-900 font-bold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all duration-300 flex items-center gap-2"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    {selectedWatch.stock === 0 ? 'Sold Out' : 'Add to Cart'}
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Wix Publish Guide Modal */}
      <AnimatePresence>
        {isWixGuideOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-md z-50"
              onClick={() => setIsWixGuideOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed inset-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:top-12 md:bottom-12 md:w-full md:max-w-3xl bg-gray-900 rounded-2xl z-50 overflow-hidden flex flex-col border border-purple-500/30 shadow-2xl"
            >
              <div className="p-6 bg-gradient-to-r from-purple-900/40 via-gray-900 to-gray-900 border-b border-gray-800 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold text-lg">
                    W
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Publishing to Wix.com</h3>
                    <p className="text-xs text-purple-300">Complete static embed guide for authorized resellers</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsWixGuideOpen(false)}
                  className="p-2 text-gray-400 hover:text-white transition-colors rounded-lg hover:bg-gray-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 md:p-8 overflow-y-auto space-y-6 text-gray-300 text-sm flex-1 leading-relaxed">
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 flex gap-3 items-start">
                  <Sparkles className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold block mb-1">Your App is Optimized for Wix HTML Embeds!</strong>
                    Because your application is compiled with an advanced single-file static bundler, all custom code, styles, SVG assets, and interactive payment gateway logic are bundled perfectly into standalone deployment assets.
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-base font-bold text-white flex items-center gap-2 text-purple-400">
                    <span className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-xs">1</span>
                    Option A: Copy & Paste Complete Embed Code (Recommended)
                  </h4>
                  <p>
                    Wix allows you to embed standalone advanced single-page interactive applications inside its HTML component.
                  </p>
                  <ol className="list-decimal list-inside space-y-2 pl-2 text-gray-400">
                    <li>Log in to your <strong>Wix.com Dashboard</strong> and open your site in the <strong>Wix Editor</strong>.</li>
                    <li>Click the <strong>Add Elements (+)</strong> button on the left sidebar.</li>
                    <li>Select <strong>Embed Code</strong> &gt; <strong>Embed HTML</strong>.</li>
                    <li>In the HTML settings panel, choose <strong>Code</strong>.</li>
                    <li>Open your generated <code className="text-amber-400 bg-gray-800 px-1.5 py-0.5 rounded">dist/index.html</code> single-file production bundle, copy its entire contents, and paste it directly into the Wix HTML code box.</li>
                    <li>Resize the embedded widget to fit your page width and height perfectly, then click <strong>Publish</strong>.</li>
                  </ol>
                </div>

                <hr className="border-gray-800" />

                <div className="space-y-4">
                  <h4 className="text-base font-bold text-white flex items-center gap-2 text-purple-400">
                    <span className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-xs">2</span>
                    Option B: Wix Custom Element URL Link
                  </h4>
                  <p>
                    If you prefer hosting the files externally to allow instant real-time synchronization:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 pl-2 text-gray-400">
                    <li>Upload your complete output files to free static hosting (e.g., Vercel, GitHub Pages, or Netlify).</li>
                    <li>In the Wix Editor, select <strong>Embed Code</strong> &gt; <strong>Embed HTML</strong>.</li>
                    <li>Choose <strong>Website address</strong> instead of Code, and paste your public deployment URL.</li>
                  </ol>
                </div>

                <div className="p-4 bg-gray-800 rounded-xl space-y-2 border border-gray-700">
                  <h5 className="font-bold text-white text-xs uppercase tracking-wider text-gray-400">Important Note on Real Dealer Images</h5>
                  <p className="text-xs text-gray-400">
                    All 34 luxury limited edition watches currently utilize absolute internet-wide public editorial image URLs so that directly pasting your code into Wix sandboxed iframes works out of the box with zero broken cross-origin paths.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-gray-900 border-t border-gray-800 text-right flex-shrink-0">
                <button
                  onClick={() => setIsWixGuideOpen(false)}
                  className="px-6 py-2.5 bg-gray-800 hover:bg-gray-700 text-white font-bold rounded-lg transition-colors text-xs"
                >
                  Got it, Let's Publish!
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;